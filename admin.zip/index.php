<?php
include ('includes/db.php');
?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
   <link rel="stylesheet" href="/index.css">
    <link rel="icon" type="image/png" href=""/>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1">

    <title>Admin</title>
</head>

<body>
<div class="container">
    <div class="navigation">
        <ul>
            <li>
                <a href="#">
                 <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                <span class="title">LoyaltyCard - Admin</span></a>
            </li>

            <li>
                <a href="#">
                <span class="icon"><ion-icon name="people-outline"></ion-icon></span>
                <span class="title">Gestion client</span></a>
            </li>
             <li>
                <a href="#">
                <span class="icon"><ion-icon name="business-outline"></ion-icon></span>
                <span class="title">Gestion entreprise</span></a>
            </li>
             <li>
                 <a href="#">
                <span class="icon"><ion-icon name="cash-outline"></ion-icon></span>
                <span class="title">Gestion boutique</span></a>
            </li>
            <li>
                <a href="#">
                    <span class="icon"><ion-icon name="pricetags-outline"></ion-icon></span>
                    <span class="title">Gestion des offres</span></a>
            </li>
            <li>
                <a href="#">
                    <span class="icon"><ion-icon name="call-outline"></ion-icon></span>
                    <span class="title">Contact</span></a>
            </li>
            <li>
                <a href="#">
                    <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                    <span class="title">Déconnexion</span></a>
            </li>
        </ul>
    </div>

    <div class="main">
        <div class="topbar">
            <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
            </div>
            <div class="search">
                <label>
                    <input type="text" placeholder="Search here">
                    <ion-icon name="search-outline"></ion-icon>
                </label>
            </div>

            <div class="user">
                <img src="user.jpg">
            </div>
        </div>

        <!-- cards -->
        <div class="cardBox">
            <div class="card">
                <div>
                    <div class="numbers">1,504</div>
                    <div class="cardName">Visites</div>
                </div>
                <div class="iconBx"><ion-icon name="eye-outline"></ion-icon></div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">80</div>
                    <div class="cardName">ventes</div>
                </div>
                <div class="iconBx"><ion-icon name="cart-outline"></ion-icon></ion-icon></ion-icon></div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">204</div>
                    <div class="cardName">Nouveau inscrits</div>
                </div>
                <div class="iconBx"><ion-icon name="person-add-outline"></ion-icon></ion-icon></div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">€876</div>
                    <div class="cardName">Recette</div>
                </div>
                <div class="iconBx"><ion-icon name="cash-outline"></ion-icon></ion-icon></div>
            </div>
        </div>

        <!-- data list-->
        <div class="details">
            <div class="recentOrders">
                <div class="cardHeader">
                    <h2>Commandes récentes</h2>
                    <a href="#" class="btn">Tout voir</a>
                </div>
                <table>
                    <thead>
                    <tr>
                        <td>Nom</td>
                        <td>Prix</td>
                        <td>Paiement</td>
                        <td>Status</td>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>
                    <tr>
                        <td>Star Refrigerator</td>
                        <td>200€</td>
                        <td>Paid</td>
                        <td><span class="status delivered">Livré</span></td>
                    </tr>

                    </tbody>
                </table>
            </div>

            <div class="recentCustomers">
                <div class="cardHeader">
                    <h2>Recent customer</h2>
                </div>
                <table>
                    <tr>
                        <td width="60px"><div class="imgBx"><img src="image.png"></div></td>
                        <td><h4>David<br><span>France</span></h4></td>
                    </tr>
                    <tr>
                        <td width="60px"><div class="imgBx"><img src="image.png"></div></td>
                        <td><h4>David<br><span>France</span></h4></td>
                    </tr>
                    <tr>
                        <td width="60px"><div class="imgBx"><img src="image.png"></div></td>
                        <td><h4>David<br><span>France</span></h4></td>
                    </tr>
                    <tr>
                        <td width="60px"><div class="imgBx"><img src="image.png"></div></td>
                        <td><h4>David<br><span>France</span></h4></td>
                    </tr>
                    <tr>
                        <td width="60px"><div class="imgBx"><img src="image.png"></div></td>
                        <td><h4>David<br><span>France</span></h4></td>
                    </tr>
                    <tr>
                        <td width="60px"><div class="imgBx"><img src="image.png"></div></td>
                        <td><h4>David<br><span>France</span></h4></td>
                    </tr>
                    <tr>
                        <td width="60px"><div class="imgBx"><img src="image.png"></div></td>
                        <td><h4>David<br><span>France</span></h4></td>
                    </tr>
                </table>
            </div>
        </div>

    </div>
</div>
<!-- don't forget to add icon script -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

<!-- Detect hovered li-->
<script>
    let list = document.querySelectorAll('.navigation li');

    function activeLink(){
        list.forEach((item) =>
         item.classList.remove('hovered'));
        this.classList.add('hovered');
    }
    list.forEach((item)=>
    item.addEventListener('mouseover',activeLink))
    console.log("check");

</script>

<script>
    //menu toggle
    let toggle = document.querySelector('.toggle');
    let navigation = document.querySelector('.navigation');
    let main = document.querySelector('.main');

toggle.onclick = function(){
    navigation.classList.toggle('active');
    main.classList.toggle('active');
}
</script>

</body>
</html>
